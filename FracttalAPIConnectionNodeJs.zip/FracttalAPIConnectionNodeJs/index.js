const Hawk = require("hawk");
const fetch = require("node-fetch");
const url = 'https://app.fracttal.com/api/work_orders/', //Web service Fracttal
  method = 'GET',
  credentials = {
    "id": "FracttalID",
    "key": "FracttalKey",
    "algorithm": "sha256"
  };


const GetData = async () => {

  console.log("get", url);
  const response = await fetch(url, {
    method,
    headers: {
      Authorization: generateHawkHeader(url, method),
    },
  });

  try {
    const infoResponse = await response.json();

    if (response.status != 200) {
      console.error("ERROR", JSON.stringify(infoResponse, null, 4));
    } else {
      if (!infoResponse.success) {
        console.error("ERROR", infoResponse.data.Error);
      } else {
        console.log(JSON.stringify(infoResponse.data, null, 4));
      }
    }

  } catch (error) {
    console.error("ERROR", error);
  }
};

const generateHawkHeader = (url, method) => {

  const { header: headerHawk } = Hawk.client.header(url, method, {
    credentials: credentials,
  });

  return headerHawk;
};


GetData();
