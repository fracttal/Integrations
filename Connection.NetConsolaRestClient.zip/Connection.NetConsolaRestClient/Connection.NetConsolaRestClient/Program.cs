﻿using System;
using RestSharp;
using Newtonsoft.Json;
using HawkNet;

namespace api
{
    class Program
    {
        static HawkCredential _credential;

        static void Main(string[] args)
        {
            HawkCredential credential = new HawkCredential
            {
                Id = "YOUR_ID",
                Key = "YOUR_KEY",
                Algorithm = "sha256"
            };

            _credential = credential;

            var client = new RestClient("https://app.fracttal.com/api/inventories_details/");
            var request = new RestRequest(Method.GET);
            Authenticate(client, request);
            IRestResponse response = client.Execute(request);
            var jsonResponse = JsonConvert.DeserializeObject(response.Content);
            Console.WriteLine(jsonResponse);
        }


        static public void Authenticate(IRestClient client, IRestRequest request)
        {
            var uri = client.BuildUri(request);
            var portSuffix = uri.Port != 80 ? ":" + uri.Port : "";
            var host = uri.Host + portSuffix;
            var method = request.Method.ToString();

            var header = Hawk.GetAuthorizationHeader(host, method, uri, _credential);

            request.AddHeader("Authorization", "Hawk " + header);
        }


    }
}